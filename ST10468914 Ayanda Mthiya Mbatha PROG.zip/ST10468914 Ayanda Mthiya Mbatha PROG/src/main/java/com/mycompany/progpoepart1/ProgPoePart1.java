/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.progpoepart1;
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.regex.Pattern;
/**
 *
 * @author RC_Student_lab
 */
public class ProgPoePart1 {
    
       
        
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        String registeredUsername = "";
        String registeredPassword = "";
        
        System.out.println("=== Welcome to the Registration Page ===");
        
        //Registration
        System.out.print("Register a username: ");
        registeredUsername = scanner.nextLine();
        
        System.out.print("Register a password: ");
        registeredPassword = scanner.nextLine();
        
        System.out.println("\nRegistration successful!");
        System.out.println("Please log in to continue.");
        
        //Login
        int attempts = 0;
        int maxAttempts = 3;
        boolean isLoggedIn = false;
        
        while (attempts < maxAttempts && !isLoggedIn) {
            System.out.print("\nEnter username: ");
            String username = scanner.nextLine();
            
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            
            if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
                System.out.println("Login succesful! Welcome, " +username + "+");
                isLoggedIn = true;
            } else {
                attempts++;
                int remaining = maxAttempts - attempts;
                System.out.println("Incorrect username or password. Attempts remaining: " + remaining);
            }
            
            
        }
        
        if (!isLoggedIn) {
            System.out.println("Too many failed attempts. Account locked.");
            return;
        
           
           
            
           
        }
        
       
        

        //Phone number input and validation
        String phoneNumber = JOptionPane.showInputDialog("Enter your cell phone number with country code");
        
        //Regular expression to match valid phone numbers
        String regex = "\\+\\d{1,3}\\d{1,10}$";
        
        if (Pattern.matches(regex, phoneNumber)) {
            JOptionPane.showMessageDialog(null, "Cell phone number successfully added." );
        } else {
            JOptionPane.showMessageDialog(null, "Cell phone number incorrectly formatted or does not exist");
        }
        
        scanner.close();
        
        
        
        
        
        
        
       
      
    }
}
//Assistance from ChatGPT(OpenAI,2025).Retrieved from https://chat.openai.com/.